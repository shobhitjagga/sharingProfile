#define BLK_OFFSET 6

#define NUM_SETS 2048
#define NUM_WAYS 16
